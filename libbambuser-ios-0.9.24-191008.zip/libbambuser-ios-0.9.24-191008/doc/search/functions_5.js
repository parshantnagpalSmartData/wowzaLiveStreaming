var searchData=
[
  ['healthupdated_3a',['healthUpdated:',['../protocol_bambuser_view_delegate-p.html#a73c12409d769733eaa456008ff4ed614',1,'BambuserViewDelegate-p']]]
];
