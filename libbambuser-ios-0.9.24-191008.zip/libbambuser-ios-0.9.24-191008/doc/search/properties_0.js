var searchData=
[
  ['applicationid',['applicationId',['../interface_bambuser_view.html#a5cb91ea343707e180ac30d341b2e452f',1,'BambuserView::applicationId()'],['../interface_bambuser_player.html#a9055bb58dfcb6d7b3cb2750343f14cfc',1,'BambuserPlayer::applicationId()']]],
  ['audioqualitypreset',['audioQualityPreset',['../interface_bambuser_view.html#ae511589dad6b40bc5d76bb7cfbf34d68',1,'BambuserView']]],
  ['author',['author',['../interface_bambuser_view.html#a62481f55c9aae533463f21517b8dbc4e',1,'BambuserView']]]
];
