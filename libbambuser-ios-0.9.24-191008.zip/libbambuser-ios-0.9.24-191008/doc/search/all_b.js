var searchData=
[
  ['orientation',['orientation',['../interface_bambuser_view.html#ab23d6ea258ab2c84a4171f89eb17f36e',1,'BambuserView']]]
];
