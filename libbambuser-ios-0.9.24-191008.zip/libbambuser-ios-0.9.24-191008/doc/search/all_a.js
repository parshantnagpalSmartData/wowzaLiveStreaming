var searchData=
[
  ['maxbroadcastdimension',['maxBroadcastDimension',['../interface_bambuser_view.html#a538f90a4d5a443b3ddfc111087a44d8a',1,'BambuserView']]],
  ['maxzoom',['maxZoom',['../interface_bambuser_view.html#a32977fb1ef5f7eac6e90037babd4382f',1,'BambuserView']]],
  ['minframerate',['minFramerate',['../interface_bambuser_view.html#a15e0412fa411f7cdcca03e5cff913045',1,'BambuserView']]]
];
