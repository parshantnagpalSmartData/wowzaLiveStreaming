var searchData=
[
  ['latencymeasurement',['LatencyMeasurement',['../struct_latency_measurement.html',1,'']]]
];
