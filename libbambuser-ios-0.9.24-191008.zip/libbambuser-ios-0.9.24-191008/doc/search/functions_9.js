var searchData=
[
  ['seekto_3a',['seekTo:',['../interface_bambuser_player.html#a7f210270012dfb478d6ead0a49eb91b2',1,'BambuserPlayer']]],
  ['setframerate_3aminframerate_3a',['setFramerate:minFramerate:',['../interface_bambuser_view.html#a27ca4e01c4ec4e3296da7b11b7d1da92',1,'BambuserView']]],
  ['setorientation_3aprevieworientation_3a',['setOrientation:previewOrientation:',['../interface_bambuser_view.html#aa214fda1010ae336deffa9c464716f71',1,'BambuserView']]],
  ['setorientation_3aprevieworientation_3awithaspect_3aby_3a',['setOrientation:previewOrientation:withAspect:by:',['../interface_bambuser_view.html#a7f72dc40c42ba85a3c4790c80d9a58c0',1,'BambuserView']]],
  ['setvideoqualitypreset_3a',['setVideoQualityPreset:',['../interface_bambuser_view.html#a0044c1b7259f5ad4ca3f1d3659edd182',1,'BambuserView']]],
  ['snapshottaken_3a',['snapshotTaken:',['../protocol_bambuser_view_delegate-p.html#aa3e53b91744bc0ccfa0b2bdf04e1fd56',1,'BambuserViewDelegate-p']]],
  ['startbroadcasting',['startBroadcasting',['../interface_bambuser_view.html#a2e7e8da058c248f5d95ae8c4df95baff',1,'BambuserView']]],
  ['startcapture',['startCapture',['../interface_bambuser_view.html#a2668b23cb68399265063b85d4285084b',1,'BambuserView']]],
  ['startlinktest',['startLinktest',['../interface_bambuser_view.html#a290115cc5e66bd9825226af9d06b4c1a',1,'BambuserView']]],
  ['stopbroadcasting',['stopBroadcasting',['../interface_bambuser_view.html#a7a56ee4d0d88f21859222b2a6a5e4b46',1,'BambuserView']]],
  ['stopvideo',['stopVideo',['../interface_bambuser_player.html#a9fff79bdf137f67b90461d445a84d07f',1,'BambuserPlayer']]],
  ['swapcamera',['swapCamera',['../interface_bambuser_view.html#a9c91a2f2e8bf4451b74aba17fa8b853f',1,'BambuserView']]]
];
