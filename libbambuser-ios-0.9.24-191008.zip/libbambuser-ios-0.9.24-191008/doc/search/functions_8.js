var searchData=
[
  ['recordingcomplete_3a',['recordingComplete:',['../protocol_bambuser_view_delegate-p.html#a644f3e14773f262e175eb6300b286e22',1,'BambuserViewDelegate-p']]]
];
