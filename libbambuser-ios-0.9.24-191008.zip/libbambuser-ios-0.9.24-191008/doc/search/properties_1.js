var searchData=
[
  ['broadcasttitle',['broadcastTitle',['../interface_bambuser_view.html#a3b9196def35b273cc9b481526e19a071',1,'BambuserView']]]
];
