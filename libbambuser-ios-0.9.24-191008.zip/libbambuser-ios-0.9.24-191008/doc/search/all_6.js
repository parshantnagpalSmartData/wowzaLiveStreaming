var searchData=
[
  ['hasfrontcamera',['hasFrontCamera',['../interface_bambuser_view.html#a09f4bb74b1adc78c1f7cef762fe26fe3',1,'BambuserView']]],
  ['hasledtorch',['hasLedTorch',['../interface_bambuser_view.html#a033396583ae858c446c97ca9d6244d5b',1,'BambuserView']]],
  ['health',['health',['../interface_bambuser_view.html#a914ee7ae7e22a457e2b6fe885a2bdc4b',1,'BambuserView']]],
  ['healthupdated_3a',['healthUpdated:',['../protocol_bambuser_view_delegate-p.html#a73c12409d769733eaa456008ff4ed614',1,'BambuserViewDelegate-p']]]
];
