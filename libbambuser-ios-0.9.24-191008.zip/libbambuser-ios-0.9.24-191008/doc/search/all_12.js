var searchData=
[
  ['zoom',['zoom',['../interface_bambuser_view.html#a2c119639c7c100f3694e3d1448a95206',1,'BambuserView']]]
];
