var searchData=
[
  ['uplinktestcomplete_3arecommendation_3a',['uplinkTestComplete:recommendation:',['../protocol_bambuser_view_delegate-p.html#a80c46e7074854bc380340bba449f60bc',1,'BambuserViewDelegate-p']]]
];
