var searchData=
[
  ['uplinkrecommendation',['uplinkRecommendation',['../interface_bambuser_view.html#a53089d4b7fde771ecb03f5228c2e675e',1,'BambuserView']]],
  ['uplinkspeed',['uplinkSpeed',['../interface_bambuser_view.html#ab43ce92c4ffb7f4e941eb918672553cc',1,'BambuserView']]]
];
