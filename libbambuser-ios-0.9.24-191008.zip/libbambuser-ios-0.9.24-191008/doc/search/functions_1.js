var searchData=
[
  ['bambusererror_3amessage_3a',['bambuserError:message:',['../protocol_bambuser_view_delegate-p.html#aa0e2866c3550df234e8f92fd17d4ea28',1,'BambuserViewDelegate-p']]],
  ['broadcastidreceived_3a',['broadcastIdReceived:',['../protocol_bambuser_view_delegate-p.html#a2a7120750c19a1ba748cea0baa509126',1,'BambuserViewDelegate-p']]],
  ['broadcaststarted',['broadcastStarted',['../protocol_bambuser_view_delegate-p.html#a22dbc54fca36a3cb1c004434c9c4dc3b',1,'BambuserViewDelegate-p']]],
  ['broadcaststopped',['broadcastStopped',['../protocol_bambuser_view_delegate-p.html#a9c889ba598369543bed814ae7b9efd11',1,'BambuserViewDelegate-p']]]
];
