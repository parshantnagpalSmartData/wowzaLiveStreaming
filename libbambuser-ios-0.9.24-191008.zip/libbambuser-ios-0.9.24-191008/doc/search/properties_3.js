var searchData=
[
  ['delegate',['delegate',['../interface_bambuser_view.html#a0cda428bd08957a72b0ff493dddd8f39',1,'BambuserView::delegate()'],['../interface_bambuser_player.html#ab995a9172acf37fbefec0b002a598998',1,'BambuserPlayer::delegate()']]]
];
