var searchData=
[
  ['framerate',['framerate',['../interface_bambuser_view.html#af90dc44b5d1dfba771bf22230167d419',1,'BambuserView']]]
];
