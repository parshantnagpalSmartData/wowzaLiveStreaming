var searchData=
[
  ['endtalkback',['endTalkback',['../interface_bambuser_view.html#ae508b55d0e9306dfffdcb246a5eb52d2',1,'BambuserView']]]
];
