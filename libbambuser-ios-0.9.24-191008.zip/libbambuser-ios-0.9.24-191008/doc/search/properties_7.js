var searchData=
[
  ['live',['live',['../interface_bambuser_player.html#a93002e325f5e3d3c40c0242f0643aade',1,'BambuserPlayer']]],
  ['localfilename',['localFilename',['../interface_bambuser_view.html#aff4ed2f01d20845f3747e682d5a5525d',1,'BambuserView']]]
];
