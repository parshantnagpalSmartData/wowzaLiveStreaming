var searchData=
[
  ['playbackposition',['playbackPosition',['../interface_bambuser_player.html#a7c3f649c8e142bf48eb9bfbf115f669d',1,'BambuserPlayer']]],
  ['previewframe',['previewFrame',['../interface_bambuser_view.html#a14baf0a31b5234988ca76a5205e8ef75',1,'BambuserView']]],
  ['previeworientation',['previewOrientation',['../interface_bambuser_view.html#a6e00ad831228a9040edf8e810c6dd45f',1,'BambuserView']]]
];
