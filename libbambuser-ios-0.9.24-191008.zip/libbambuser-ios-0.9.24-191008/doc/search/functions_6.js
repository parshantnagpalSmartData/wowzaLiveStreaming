var searchData=
[
  ['init',['init',['../interface_bambuser_player.html#abb4fe463d4dab80476c62714dc37a726',1,'BambuserPlayer']]],
  ['initwithpreparepreset_3a',['initWithPreparePreset:',['../interface_bambuser_view.html#a87b695ff2ce1269c1fbc827f8145ecf3',1,'BambuserView']]],
  ['initwithpreset_3a',['initWithPreset:',['../interface_bambuser_view.html#a4f7eaa52f0b245b06439c6e34f82111b',1,'BambuserView']]]
];
