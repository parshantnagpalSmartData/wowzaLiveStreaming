var searchData=
[
  ['accepttalkbackrequest_3a',['acceptTalkbackRequest:',['../interface_bambuser_view.html#a0aa5e9d38c93da5d11bca4733bce6ebf',1,'BambuserView']]]
];
