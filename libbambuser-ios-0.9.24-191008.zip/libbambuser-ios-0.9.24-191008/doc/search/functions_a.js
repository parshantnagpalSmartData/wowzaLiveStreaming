var searchData=
[
  ['takesnapshot',['takeSnapshot',['../interface_bambuser_view.html#a0f454d0ed6bd79d91431d9e86a9a3986',1,'BambuserView']]],
  ['talkbackrequest_3acaller_3atalkbackid_3a',['talkbackRequest:caller:talkbackID:',['../protocol_bambuser_view_delegate-p.html#a4153b1ba656495fbf2ddc4684b959078',1,'BambuserViewDelegate-p']]],
  ['talkbackstatechanged_3a',['talkbackStateChanged:',['../protocol_bambuser_view_delegate-p.html#ab085e747ae0b71767eeb9a935c5d04c5',1,'BambuserViewDelegate-p']]],
  ['totalviewercountupdated_3a',['totalViewerCountUpdated:',['../protocol_bambuser_view_delegate-p.html#a8eb4e0ea2bd749a18f61c6a6b5c72398',1,'BambuserViewDelegate-p::totalViewerCountUpdated:()'],['../protocol_bambuser_player_delegate-p.html#abfa84eba6226280bdbe31c874805ab6f',1,'BambuserPlayerDelegate-p::totalViewerCountUpdated:()']]]
];
