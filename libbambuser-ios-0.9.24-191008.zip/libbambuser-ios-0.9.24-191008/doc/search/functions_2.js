var searchData=
[
  ['chatmessagereceived_3a',['chatMessageReceived:',['../protocol_bambuser_view_delegate-p.html#a152582dc3dacae3d19cf74a2e82ce204',1,'BambuserViewDelegate-p']]],
  ['currentviewercountupdated_3a',['currentViewerCountUpdated:',['../protocol_bambuser_view_delegate-p.html#a9de461ea98dbd88183fdb0bdbc7183de',1,'BambuserViewDelegate-p::currentViewerCountUpdated:()'],['../protocol_bambuser_player_delegate-p.html#aef1b2910addb79cf370c94200ac58dd7',1,'BambuserPlayerDelegate-p::currentViewerCountUpdated:()']]]
];
