function resizeIframe(obj) {
    obj.style.height = window.innerHeight + 'px';
}

$( document ).ready(function() {
    $(window).on('resize', function() {
          var win = $(this);
          $("iframe.full-window").each(function(index) {
              var parentHeight = $("#typehead").parent().height();
              $(this).height(win.height());
          });
    });

    $('.sidebar table tr td a').attr('target', 'contentFrame');

    $('#content-frame').on('load', function() {
            resizeIframe($(this)[0]);
    });
});
