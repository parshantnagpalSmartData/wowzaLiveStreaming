function resizeIframe(obj) {
    obj.style.height = (window.innerHeight - 50) + 'px';
}

function showPlatformContent(platform) {
    var otherPlatform = (platform == "ios" ? "android" : "ios");

    var platformClass = ".platform-content-" + platform;
    var otherPlatformClass  = ".platform-content-" + otherPlatform;

    $(otherPlatformClass).hide();
    $(platformClass).fadeIn('slow');

    ga('send', {
      hitType: 'event',
      eventCategory: 'PlatformSelection',
      eventAction: platform
    });
}

/* Prevent disabled links from causing a page reload */
$("li.disabled a").click(function() {
    event.preventDefault();
});

/* Highlight */
$( document ).ready(function() {
    $(window).on('resize', function() {
          var win = $(this); //this = window
          $("iframe.external-doc").each(function(index) {
              $(this).height(win.height() - 50);
              console.log("setting iframe height to: " + win.height() - 50);
          });
    });

    $(".platform-content-selector input[name='platform']").change(function() {
        var platform = $(this).val();

        Cookies.set('WOWZA_PLATFORM', platform, { expires: 365 });
        showPlatformContent(platform);
    });

    hljs.initHighlightingOnLoad();

    $('table').addClass('table table-striped table-hover');

    var contentPlatform = Cookies.get('WOWZA_PLATFORM');
    if (typeof contentPlatform == 'undefined') contentPlatform = 'ios';

    if ($(".platform-content-ios").size() == 0 || $(".platform-content-android").size() == 0) {
        $(".platform-content-selector").hide();
    } else {
        $(".platform-content-selector label.platform-" + contentPlatform).addClass('active');
        showPlatformContent(contentPlatform);
    }

    $("code.api-class").click(function() {
        selectedApiClass=$(this).html();
        $('#apiBrowser').modal();
    });

    var selectedApiClass="WowzaGoCoder";
    $('#apiBrowser').on('show.bs.modal', function () {
        var modalWidth = $( window ).width()*0.8;
        var modalHeight = $( window ).height()*0.9;
        var modalHMargin = Math.floor(($( window ).width() - modalWidth) / 2.0);
        var modalVMargin = Math.floor(($( window ).height() - modalHeight) / 2.0);

        $('#apiBrowser .modal-content').css('width', modalWidth);
        $('#apiBrowser .modal-content').css('height', modalHeight);

        $('#apiBrowser .modal-dialog').css('margin-left', modalHMargin);
        $('#apiBrowser .modal-dialog').css('margin-right', modalHMargin);

        $('#apiBrowser .modal-dialog').css('margin-top', modalVMargin);
        $('#apiBrowser .modal-dialog').css('margin-bottom', modalVMargin);

        $('#apiBrowser .modal-content .modal-body iframe').css('height', modalHeight);

        $('#apiBrowser .modal-content .modal-body iframe').attr('src', "/resources/gocodersdk/docs/1.0/api-docs-android/com/wowza/gocoder/sdk/api/devices/WZCamera.html");
    });

});
