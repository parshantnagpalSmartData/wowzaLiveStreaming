//
//  
//  WowzaGoCoderSDK 
//  © 2016 – 2019 Wowza Media Systems, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WOWZPlayerViewController : UIViewController

@end
