//
//  GSDKUITests_swift.swift
//  GSDKUITests-swift
//
//  Created by GeorgeM on 9/17/19.
//  Copyright © 2019 Wowza. All rights reserved.
//

import XCTest
import Foundation
import UIKit

extension XCUIElement {
    func clearText(andReplaceWith newText:String? = nil) {
        tap()
        tap() //When there is some text, its parts can be selected on the first tap, the second tap clears the selection
        press(forDuration: 1.0)
        let selectAll = XCUIApplication().menuItems["Select All"]
        //For empty fields there will be no "Select All", so we need to check
        if selectAll.waitForExistence(timeout: 0.2), selectAll.exists {
            selectAll.tap()
            typeText(String(XCUIKeyboardKey.delete.rawValue))
        }
        if let newVal = newText { typeText(newVal) }
    }
}

class GSDKUITests_swift: XCTestCase {
    
    
    
    
    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        
        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        // XCUIApplication().launch()
        let app = XCUIApplication(bundleIdentifier: "com.wowza.sdk.demo.GoCoder-SDK")
        app.launch()
        // XCUIApplication *app = XCUIApplication()
        // app.launch
        
        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        let app = XCUIApplication()
        app.terminate()
        
    }
    // MARK: - Helper Functions
    func selectBroadcastApp () {
        let app = XCUIApplication()
        let tablesQuery = app.tables
        //start broadcaster app
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Broadcast a live video and audio stream captured with the local camera and mic"]/*[[".cells.staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]",".staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        
    }
    
    func configBroadcastSettingsWParms (app : XCUIApplication, host : String, port:String , applicationName:String, stream_Name:String, UserName user_Name:String? = nil, Password passw:String? = nil) {
        //configures Settings with parmeterized values having username and password optional
        //then exits settings
        let tablesQuery = app.tables
        //start broadcaster app
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Broadcast a live video and audio stream captured with the local camera and mic"]/*[[".cells.staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]",".staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        app.buttons["settings button"].tap() //get to broadcaster settings
        
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["3840x2160 (4k UHD) @ 8mbps"]/*[[".cells.staticTexts[\"3840x2160 (4k UHD) @ 8mbps\"]",".staticTexts[\"3840x2160 (4k UHD) @ 8mbps\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        //update host Address field
        let hostfield = tablesQuery.cells.containing(.staticText, identifier:"Host Address").children(matching: .textField).element
        hostfield.clearText(andReplaceWith: host)
        
        tablesQuery.staticTexts["Wowza Broadcast Settings"].swipeUp()
        let portfield =  tablesQuery.cells.containing(.staticText, identifier:"Port").children(matching: .textField).element
        portfield.clearText(andReplaceWith: port)
        
        let appName = tablesQuery.cells.containing(.staticText, identifier:"Application Name").children(matching: .textField).element
        appName.clearText(andReplaceWith: applicationName)
        
        let streamName = tablesQuery.cells.containing(.staticText, identifier:"Stream Name").children(matching: .textField).element
        streamName.clearText(andReplaceWith: stream_Name)
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Stream Name"]/*[[".cells.staticTexts[\"Stream Name\"]",".staticTexts[\"Stream Name\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.swipeUp()
        
        let userName =  tablesQuery.cells.containing(.staticText, identifier:"User name").children(matching: .textField).element
        userName.clearText(andReplaceWith: user_Name)
        
        let password = tablesQuery.cells.containing(.staticText, identifier:"Password").children(matching: .secureTextField).element
        password.clearText(andReplaceWith: passw)
        
        
        //clear the keyboard
        app.toolbars["Toolbar"].buttons["Done"].tap()
        //exit Broadcast settings
        app.navigationBars["Settings"].buttons["Done"].tap()
        
        
    }
    
    func configBroadcastSettings (app : XCUIApplication) {
        //configures Settings with predefined values.
        //then gets back to Sample App list
        let tablesQuery = app.tables
        //start broadcaster app
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Broadcast a live video and audio stream captured with the local camera and mic"]/*[[".cells.staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]",".staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        app.buttons["settings button"].tap() //get to broadcaster settings
        
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["3840x2160 (4k UHD) @ 8mbps"]/*[[".cells.staticTexts[\"3840x2160 (4k UHD) @ 8mbps\"]",".staticTexts[\"3840x2160 (4k UHD) @ 8mbps\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        //update host Address field
        let hostfield = tablesQuery.cells.containing(.staticText, identifier:"Host Address").children(matching: .textField).element
        hostfield.clearText(andReplaceWith: "192.168.1.6")
        
        tablesQuery.staticTexts["Wowza Broadcast Settings"].swipeUp()
        let portfield =  tablesQuery.cells.containing(.staticText, identifier:"Port").children(matching: .textField).element
        portfield.clearText(andReplaceWith: "1935")
        
        let appName = tablesQuery.cells.containing(.staticText, identifier:"Application Name").children(matching: .textField).element
        appName.clearText(andReplaceWith: "live")
        
        let streamName = tablesQuery.cells.containing(.staticText, identifier:"Stream Name").children(matching: .textField).element
        streamName.clearText(andReplaceWith: "QAStreamTest")
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Stream Name"]/*[[".cells.staticTexts[\"Stream Name\"]",".staticTexts[\"Stream Name\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.swipeUp()
        
        let userName =  tablesQuery.cells.containing(.staticText, identifier:"User name").children(matching: .textField).element
        userName.clearText(andReplaceWith: "test")
        
        let password = tablesQuery.cells.containing(.staticText, identifier:"Password").children(matching: .secureTextField).element
        password.clearText(andReplaceWith: "test")
        
        
        //clear the keyboard
        app.toolbars["Toolbar"].buttons["Done"].tap()
        //exit Broadcast settings
        app.navigationBars["Settings"].buttons["Done"].tap()
        
        
    }
    
    
    
    // MARK: - UI Tests
    func test_0001_CameraMicPermissions() {
        
        let app = XCUIApplication()
        app.tables/*@START_MENU_TOKEN@*/.staticTexts["Stream live video and audio"]/*[[".cells.staticTexts[\"Stream live video and audio\"]",".staticTexts[\"Stream live video and audio\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        //handle the permissions for camera and mic system prompts
        _ = addUIInterruptionMonitor(withDescription: "GSDK camera-mic permission prompts") { (alert) -> Bool in
            if alert.buttons["OK"].exists {
                alert.buttons["OK"].tap()
                return true
            }
            return false
        }
        app.tap()
        app.buttons["Close"].tap()
        
    }
    
    
    func test_0006_BroadcastLocal() {
        // Use recording to get started writing UI tests.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        
        let app = XCUIApplication()
        //configBroadcastSettings(app: app)
        let tablesQuery = app.tables
        tablesQuery/*@START_MENU_TOKEN@*/.cells.staticTexts["Broadcast a live video and audio stream captured with the local camera and mic"]/*[[".cells.staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]",".staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]"],[[[-1,1],[-1,0]]],[1]]@END_MENU_TOKEN@*/.tap()
        
        
        app.buttons["settings button"].tap()
        
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["3840x2160 (4k UHD) @ 8mbps"]/*[[".cells.staticTexts[\"3840x2160 (4k UHD) @ 8mbps\"]",".staticTexts[\"3840x2160 (4k UHD) @ 8mbps\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        let hostfield = tablesQuery.cells.containing(.staticText, identifier:"Host Address").children(matching: .textField).element
        hostfield.clearText(andReplaceWith: "192.168.1.6")
        
        tablesQuery.staticTexts["Wowza Broadcast Settings"].swipeUp()
        let portfield =  tablesQuery.cells.containing(.staticText, identifier:"Port").children(matching: .textField).element
        portfield.clearText(andReplaceWith: "1935")
        
        let appName = tablesQuery.cells.containing(.staticText, identifier:"Application Name").children(matching: .textField).element
        appName.clearText(andReplaceWith: "live")
        
        let streamName = tablesQuery.cells.containing(.staticText, identifier:"Stream Name").children(matching: .textField).element
        streamName.clearText(andReplaceWith: "QAStreamTestLocal")
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Stream Name"]/*[[".cells.staticTexts[\"Stream Name\"]",".staticTexts[\"Stream Name\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.swipeUp()
        
        let userName =  tablesQuery.cells.containing(.staticText, identifier:"User name").children(matching: .textField).element
        userName.clearText(andReplaceWith: "test")
        
        let password = tablesQuery.cells.containing(.staticText, identifier:"Password").children(matching: .secureTextField).element
        password.clearText(andReplaceWith: "test")
        
        
        //clear the keyboard
        app.toolbars["Toolbar"].buttons["Done"].tap()
        
        //exit Broadcast settings
        app.navigationBars["Settings"].buttons["Done"].tap()
        
        //close Broadcaster
        //app.buttons["Close"].tap()
        sleep(2)
        //start broadcast
        //app.tables/*@START_MENU_TOKEN@*/.staticTexts["Broadcast a live video and audio stream captured with the local camera and mic"]/*[[".cells.staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]",".staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        //tablesQuery/*@START_MENU_TOKEN@*/.cells.staticTexts["Broadcast a live video and audio stream captured with the local camera and mic"]/*[[".cells.staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]",".staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]"],[[[-1,1],[-1,0]]],[1]]@END_MENU_TOKEN@*/.tap()
        //app.tables/*@START_MENU_TOKEN@*/.staticTexts["Broadcast a live video and audio stream captured with the local camera and mic"]/*[[".cells.staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]",".staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        
        app.buttons["start button"].tap()  //Bug in build 1409: crashes GSDK, b1421 fixes.
        sleep(5)
        // Stop broadcast
        app.buttons["stop button"].tap()
        
        app.buttons["Close"].tap()
        
        //selectBroadcastApp()
        //app.tables/*@START_MENU_TOKEN@*/.cells.staticTexts["Broadcast a live video and audio stream captured with the local camera and mic"]/*[[".cells.staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]",".staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]"],[[[-1,1],[-1,0]]],[1]]@END_MENU_TOKEN@*/.isAccessibilityElement = true
        
        //Bug: When Broadcaster app is highlighted (ie greyed) its not selectable, have to defocus to another app
        //tablesQuery/*@START_MENU_TOKEN@*/.cells.staticTexts["Displays an active live stream from Wowza Streaming Engine, WSC, or ULL"]/*[[".cells.staticTexts[\"Displays an active live stream from Wowza Streaming Engine, WSC, or ULL\"]",".staticTexts[\"Displays an active live stream from Wowza Streaming Engine, WSC, or ULL\"]"],[[[-1,1],[-1,0]]],[1]]@END_MENU_TOKEN@*/.tap()
        
        //app.buttons["Close"].tap()
        //app.tables/*@START_MENU_TOKEN@*/.cells.staticTexts["Broadcast a live video and audio stream captured with the local camera and mic"]/*[[".cells.staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]",".staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]"],[[[-1,1],[-1,0]]],[1]]@END_MENU_TOKEN@*/.tap()
        
        //Done.
        
        
        
    }
    
    func test_0004_ConfigBroadcasterSettings() {
        
        let app = XCUIApplication()
        configBroadcastSettings(app: app)
        
        //close Broadcaster
        //app.buttons["Close"].tap()
        
        
    }
    
    func test_0005_ConfigBroadcasterLocalwParams() {
        
        let app = XCUIApplication()
        //configBroadcastSettings(app: app)
        configBroadcastSettingsWParms(app: app, host: "192.168.1.6", port: "1935", applicationName: "live", stream_Name: "QAStreamParamsTest", UserName: "test", Password: "test")
        
        //close Broadcaster
        //app.buttons["Close"].tap()
        
        
    }
    
    func test_0002_CheckAllSampleAppsExist() {
        
        let app = XCUIApplication()
        let tablesQuery = app.tables
        
        XCTAssertTrue(tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Broadcast a live video and audio stream captured with the local camera and mic"]/*[[".cells.staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]",".staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists)
        
        XCTAssertTrue(tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Displays an active live stream from Wowza Streaming Engine, WSC, or ULL"]/*[[".cells.staticTexts[\"Displays an active live stream from Wowza Streaming Engine, WSC, or ULL\"]",".staticTexts[\"Displays an active live stream from Wowza Streaming Engine, WSC, or ULL\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists, "Playback app does not exist.")
        
        XCTAssertTrue(tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Broadcast a video from an MP4 file stored on local device."]/*[[".cells.staticTexts[\"Broadcast a video from an MP4 file stored on local device.\"]",".staticTexts[\"Broadcast a video from an MP4 file stored on local device.\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists, "Stream MP4 app does not exist.")
        
        XCTAssertTrue(tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Broadcast a live video while saving it to a MP4 file. (check settings)"]/*[[".cells.staticTexts[\"Broadcast a live video while saving it to a MP4 file. (check settings)\"]",".staticTexts[\"Broadcast a live video while saving it to a MP4 file. (check settings)\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists, "Capture MP4 app does not exist.")
        
        XCTAssertTrue(tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Capture SceneKit output"]/*[[".cells.staticTexts[\"Capture SceneKit output\"]",".staticTexts[\"Capture SceneKit output\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists, "SceneKit app does not exist.")
        
        XCTAssertTrue(tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Display a bitmap as an overlay on the camera preview."]/*[[".cells.staticTexts[\"Display a bitmap as an overlay on the camera preview.\"]",".staticTexts[\"Display a bitmap as an overlay on the camera preview.\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists, "SceneKit app does not exist.")
        
        XCTAssertTrue(  tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Broadcast metadata and register to receive metatdata during playback."]/*[[".cells.staticTexts[\"Broadcast metadata and register to receive metatdata during playback.\"]",".staticTexts[\"Broadcast metadata and register to receive metatdata during playback.\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists, "MetaData app does not exist.")
        // tablesQuery.staticTexts["GoCoder SDK v1.8.1.1409"].tap()
        
    }
    
    func test_0003_CheckAllSampleAppAreAccessible() {
        
        let app = XCUIApplication()
        let tablesQuery = app.tables
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Broadcast a live video and audio stream captured with the local camera and mic"]/*[[".cells.staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]",".staticTexts[\"Broadcast a live video and audio stream captured with the local camera and mic\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        let closeButton = app.buttons["Close"]
        closeButton.tap()
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Displays an active live stream from Wowza Streaming Engine, WSC, or ULL"]/*[[".cells.staticTexts[\"Displays an active live stream from Wowza Streaming Engine, WSC, or ULL\"]",".staticTexts[\"Displays an active live stream from Wowza Streaming Engine, WSC, or ULL\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        closeButton.tap()
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Broadcast a video from an MP4 file stored on local device."]/*[[".cells.staticTexts[\"Broadcast a video from an MP4 file stored on local device.\"]",".staticTexts[\"Broadcast a video from an MP4 file stored on local device.\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        closeButton.tap()
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Broadcast a live video while saving it to a MP4 file. (check settings)"]/*[[".cells.staticTexts[\"Broadcast a live video while saving it to a MP4 file. (check settings)\"]",".staticTexts[\"Broadcast a live video while saving it to a MP4 file. (check settings)\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        closeButton.tap()
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Capture SceneKit output"]/*[[".cells.staticTexts[\"Capture SceneKit output\"]",".staticTexts[\"Capture SceneKit output\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        app.buttons["CLOSE"].tap()
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Display a bitmap as an overlay on the camera preview."]/*[[".cells.staticTexts[\"Display a bitmap as an overlay on the camera preview.\"]",".staticTexts[\"Display a bitmap as an overlay on the camera preview.\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        closeButton.tap()
        tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Broadcast metadata and register to receive metatdata during playback."]/*[[".cells.staticTexts[\"Broadcast metadata and register to receive metatdata during playback.\"]",".staticTexts[\"Broadcast metadata and register to receive metatdata during playback.\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        closeButton.tap()
        // tablesQuery.staticTexts["GoCoder SDK v1.8.1.1409"].tap()
        
    }
    func test_0007_Broadcast2WhiteKnight() {
        
        let app = XCUIApplication()
        //configBroadcastSettings(app: app)
        configBroadcastSettingsWParms(app: app, host: "198.233.230.204", port: "1935", applicationName: "live", stream_Name: "QAutomationStreamTest", UserName: "test", Password: "test")
        app.buttons["start button"].tap() //start broadcast
        sleep(5)
        app.buttons["stop button"].tap() // Stop broadcast
        app.buttons["Close"].tap() //close Broadcaster
        
        
    }
    func test_0008_Broadcast2PushULL() {
        
        let app = XCUIApplication()
        //configBroadcastSettings(app: app)
        configBroadcastSettingsWParms(app: app, host: "origin.cdn.wowza.com", port: "1935", applicationName: "live", stream_Name: "0I0p2Y0xGWUzK2reSYhklYzZ0wL2590b")
        app.buttons["start button"].tap() //start broadcast
        sleep(5)
        app.buttons["stop button"].tap() // Stop broadcast
        app.buttons["Close"].tap() //close Broadcaster
        
        
    }
    
    
}
