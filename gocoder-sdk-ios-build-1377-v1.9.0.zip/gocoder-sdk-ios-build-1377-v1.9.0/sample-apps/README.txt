Wowza GoCoder SDK Sample Apps

For a description of each iOS sample app, see:

https://www.wowza.com/docs/how-to-install-gocoder-sdk-for-ios#sampleapps
